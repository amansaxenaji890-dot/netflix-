// Mock dataset (replace with API data if you want)
const MOVIES = [
  {id:1,title:'The Silent Shore',year:2024,genre:'Drama',length:'1h 54m',img:'https://picsum.photos/seed/m1/400/600',desc:'A moving story about family and resilience.'},
  {id:2,title:'Midnight Chase',year:2023,genre:'Action',length:'2h 6m',img:'https://picsum.photos/seed/m2/400/600',desc:'High-octane chase across neon-lit cities.'},
  {id:3,title:'Starlit Dreams',year:2022,genre:'Romance',length:'1h 48m',img:'https://picsum.photos/seed/m3/400/600',desc:'An unlikely romance under the stars.'},
  {id:4,title:'Edge of Tomorrow',year:2021,genre:'Sci-Fi',length:'2h 12m',img:'https://picsum.photos/seed/m4/400/600',desc:'A mind-bending journey through time.'},
  {id:5,title:'Hidden Truths',year:2020,genre:'Thriller',length:'1h 50m',img:'https://picsum.photos/seed/m5/400/600',desc:'A detective unravels a dangerous conspiracy.'},
  {id:6,title:'Ocean Whispers',year:2024,genre:'Adventure',length:'1h 40m',img:'https://picsum.photos/seed/m6/400/600',desc:'A voyage across mysterious seas.'},
  {id:7,title:'Neon Nights',year:2019,genre:'Crime',length:'1h 55m',img:'https://picsum.photos/seed/m7/400/600',desc:'Crime and redemption in a city that never sleeps.'},
  {id:8,title:'Laugh Riot',year:2018,genre:'Comedy',length:'1h 30m',img:'https://picsum.photos/seed/m8/400/600',desc:'A feel-good comedy for the weekend.'},
  {id:9,title:'Documented',year:2025,genre:'Documentary',length:'1h 20m',img:'https://picsum.photos/seed/m9/400/600',desc:'Exploring the unseen corners of our planet.'}
];

// Utilities
const q = sel => document.querySelector(sel);
const qa = sel => document.querySelectorAll(sel);

function createCard(movie){
  const el = document.createElement('div');
  el.className = 'card';
  el.setAttribute('tabindex','0');
  el.innerHTML = `
    <img loading="lazy" src="${movie.img}" alt="${movie.title} poster">
    <div class="meta">${movie.title} • ${movie.year}</div>
  `;
  el.addEventListener('click', ()=> openModal(movie));
  el.addEventListener('keydown', (e)=>{ if(e.key==='Enter') openModal(movie); });
  return el;
}

function populateRow(rowEl, list){
  rowEl.innerHTML = '';
  list.forEach(m=> rowEl.appendChild(createCard(m)));
}

function populateGrid(gridEl, list){
  gridEl.innerHTML = '';
  list.forEach(m=> gridEl.appendChild(createCard(m)));
}

// initial render
const trending = MOVIES.slice(0,6);
populateRow(q('#trendingRow'), trending);
populateRow(q('#recentRow'), MOVIES.slice(3));
populateGrid(q('#allGrid'), MOVIES.concat(MOVIES)); // show more cards

// hero poster random
const heroPoster = q('#heroPoster');
function setHero(movie){ heroPoster.style.backgroundImage = `url('${movie.img.replace('/400/600','/800/450')}')`; }
setHero(MOVIES[0]);

// modal
const modalBackdrop = q('#modalBackdrop');
const modalTitle = q('#modalTitle');
const modalMeta = q('#modalMeta');
const modalDesc = q('#modalDesc');
const modalLeft = q('#modalLeft');

function openModal(movie){
  modalTitle.textContent = movie.title;
  modalMeta.textContent = `${movie.year} • ${movie.genre} • ${movie.length}`;
  modalDesc.textContent = movie.desc;
  modalLeft.style.backgroundImage = `url('${movie.img.replace('/400/600','/800/600')}')`;
  modalBackdrop.style.display = 'flex';
  modalBackdrop.setAttribute('aria-hidden','false');
}
function closeModal(){ modalBackdrop.style.display = 'none'; modalBackdrop.setAttribute('aria-hidden','true'); }
q('#closeModal').addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', (e)=>{ if(e.target===modalBackdrop) closeModal(); });

// search
const searchInput = q('#searchInput');
searchInput.addEventListener('input', (e)=>{
  const v = e.target.value.trim().toLowerCase();
  if(!v){ populateGrid(q('#allGrid'), MOVIES.concat(MOVIES)); return; }
  const filtered = MOVIES.filter(m=> m.title.toLowerCase().includes(v) || m.genre.toLowerCase().includes(v));
  populateGrid(q('#allGrid'), filtered);
});

// random play
q('#randomPlay').addEventListener('click', ()=>{
  const choice = MOVIES[Math.floor(Math.random()*MOVIES.length)];
  openModal(choice);
});

// more info button opens first item
q('#moreInfo').addEventListener('click', ()=> openModal(MOVIES[0]));

// accessible keyboard close
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeModal(); });

console.info('Netflix-clone demo ready. Replace MOVIES with API or add auth, player, watchlist persistence.');
